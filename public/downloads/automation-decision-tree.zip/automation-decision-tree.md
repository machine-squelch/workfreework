# Automation Decision Tree

## Step 1. Candidate Check
1. Is the task digital **and** repeatable?
   - **No:** handle manually or redesign the process.
   - **Yes:** continue.
2. Does it happen 5+ times/week or consume >2 hours per week total?
   - **No:** park it (low ROI) until frequency increases.
   - **Yes:** continue.
3. Are the inputs structured or capturable (email, spreadsheet, CRM, API, form)?
   - **No:** design a capture/structure layer first.
   - **Yes:** continue.
4. Is the output rule-based and deterministic, or judgement/creativity heavy?
   - Rule-based → Branch A/B.
   - Judgement/pattern recognition → Branch C/D.

## Step 2. Choose Automation Path
### Branch A – Rules Automation
Use Zapier/Make when triggers and outputs are predictable. Examples: lead tagging, CRM sync, Slack alerts, templated follow-ups.

### Branch B – Script / Micro-tool
Use custom code when you need data transformation, batch jobs, or API orchestration beyond simple triggers. Examples: CSV normalization, personalized link generation, document renaming.

### Branch C – AI Assist (Human in Loop)
Use when language-heavy or nuanced tasks need drafting/summarizing before human approval. Examples: email drafts, meeting summaries, intent labeling.

### Branch D – AI-First Workflow
Use when volume is high, stakes are moderate, and you can define guardrails. Examples: first-pass support replies above confidence threshold, auto-tagging content, generating routine status summaries.

## Step 3. Sanity Check
- If the task remains pointless after automation, eliminate it entirely.
- Document each automated flow: trigger, inputs, tools, monitoring, owner.

### Mermaid Flowchart
```mermaid
flowchart TD
  A[Start] --> B{Digital & repeatable?}
  B -- No --> Z[Do manually / redesign]
  B -- Yes --> C{>2h per week or 5+ times?}
  C -- No --> Y[Defer automation]
  C -- Yes --> D{Inputs structured?}
  D -- No --> X[Create capture structure]
  D -- Yes --> E{Rule-based output?}
  E -- Yes --> F[Rules automation or scripts]
  E -- No --> G[AI assist or AI-first]
  F --> H{Still worthwhile?}
  G --> H
  H -- No --> W[Eliminate task]
  H -- Yes --> I[Document + monitor]
```
