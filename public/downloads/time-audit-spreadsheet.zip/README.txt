Time Audit Spreadsheet Template
===============================

Goal: see where your time actually goes.

Sheet 1 — Raw_Log
- Columns: Date, Day, Start_Time, End_Time, Duration_hours (`=((D2-C2)*24)`), Category, Subcategory, Description, Energy_1_5, Location, Billable, Revenue_If_Billable, Notes.
- Revenue per hour: `=IF(AND(K2="Yes",E2>0),L2/E2,"")`

Sheet 2 — Summary_By_Category
- Columns: Category, Total_Hours_This_Week, Total_Hours_This_Month, %_Of_Total_Time, %_Of_Work_Time, Avg_Energy.
- Weekly hours example: `=SUMIFS(Raw_Log!$E:$E,Raw_Log!$A:$A,">="&$B$1,Raw_Log!$A:$A,"<="&$C$1,Raw_Log!$F:$F,A2)`
- % of total time: `=B2 / SUM($B$2:$B$20)`
- Avg energy: `=AVERAGEIF(Raw_Log!$F:$F,A2,Raw_Log!$I:$I)`

Sheet 3 — Automation_Opportunities
- Filter Raw_Log for Admin/Meetings/Email/Repeats >1–2h/week.
- Columns: Task, Category, Hours_per_Week, Manual_Steps, Can_Be_Template?, Can_Be_Scripted?, Can_Be_AI_Assisted?, Next_Automation_Idea.
