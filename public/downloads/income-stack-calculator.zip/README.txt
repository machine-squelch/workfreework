Income Stack Calculator Template
================================

What you get:
1. Streams.csv — columns for Stream_Name, Category, Status, Start_Date, Target vs Current Monthly Income, Gap (`=E2-F2`), %_To_Target (`=IF(E2>0,F2/E2,0)`), Hours_per_Week, Effective_Hourly_Rate (`=IF(I2>0,(F2*12)/(I2*52),"")`), Risk_Level, Next_90_Day_Focus, Key_Next_Action.
2. Monthly_Projection.csv — input cells for Total_Income_Target (B1) + Quit_Date_Target (B2). Columns: Month, Stream_Name, Projected_Monthly_Income, Monthly_Change, Notes. Use linear growth: `=Current + Monthly_Change * N`.
3. Stack_Summary.csv — key metrics: Total_Current_Monthly (`=SUM(Streams!F:F)`), Total_Target_Monthly (`=SUM(Streams!E:E)`), Overall_%_To_Target (`=B2/B3`), plus SUMIF breakdowns by Category.

Import each CSV into sheets with the same names for formulas to resolve.
